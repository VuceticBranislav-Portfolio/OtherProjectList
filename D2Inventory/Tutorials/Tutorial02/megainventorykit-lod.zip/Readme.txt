Megainv Kit
For Diablo II Xpack

This includes the bat files, the script files, txt files and dc6 files to make
your own mods have bigger stash, cube and character inventory. If you decide to
use this in your mod, I would appreciate a link to the keep on your site or in
your readme.

In order to use these file you must import them into your D2_patch.mpq file!

Mpq2k can do this for you can download this tool from:

http://www.d2mods.com

Simply copy all the files into your mod dir alnog with mpq2k and run the megainvxp.bat!

Fusman & Phalzyr

Downloaded from:
The Phrozen Keep
www.d2mods.com

